* [6886798](https://github.com/TryGhost/Casper/commit/6886798) 2.10.3 - Fabien O'Carroll
* [42c2662](https://github.com/TryGhost/Casper/commit/42c2662) Update dependency autoprefixer to v9.6.0 - Renovate Bot
* [89a1276](https://github.com/TryGhost/Casper/commit/89a1276) Update dependency gscan to v2.6.2 - Renovate Bot
